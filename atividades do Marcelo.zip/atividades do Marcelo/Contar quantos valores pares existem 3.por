programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 3"

var
   vetor: vetor[1..10] de inteiro
   i, pares: inteiro

inicio

   pares =- 0

   para i de 1 ate 10 faca
      escreva("Digite o ", i, "º valor: ")
      leia(vetor[i])

      se vetor[i] mod 2 = 0 entao
         pares =- pares + 1
      fimse
   fimpara

   escreval("")
   escreval("Quantidade de valores pares: ", pares)

fimalgoritmo
