programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 5"

var
   vetor: vetor[1..10] de inteiro
   i, maior, posicao: inteiro

inicio

   para i de 1 ate 10 faca
      escreva("Digite o ", i, "º valor: ")
      leia(vetor[i])
   fimpara

   maior <- vetor[1]
   posicao <- 1

   para i de 2 ate 10 faca
      se vetor[i] > maior entao
         maior <- vetor[i]
         posicao <- i
      fimse
   fimpara

   escreval("")
   escreval("Vetor:")

   para i de 1 ate 10 faca
      escreva(vetor[i], " ")
   fimpara

   escreval("")
   escreval("Maior elemento: ", maior)
   escreval("Posição: ", posicao)

fimalgoritmo
