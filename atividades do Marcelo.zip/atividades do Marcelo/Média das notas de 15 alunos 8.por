programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 8"

var
   notas: vetor[1..15] de real
   soma, media: real
   i: inteiro

inicio

   soma <- 0

   para i de 1 ate 15 faca
      escreva("Digite a nota do aluno ", i, ": ")
      leia(notas[i])

      soma <- soma + notas[i]
   fimpara

   media <- soma / 15

   escreval("")
   escreval("Média geral: ", media:0:2)

fimalgoritmo
