programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 7"

var
   vetor: vetor[1..6] de inteiro
   i: inteiro

inicio

   para i de 1 ate 6 faca

      repita
         escreva("Digite um valor PAR para a posição ", i, ": ")
         leia(vetor[i])

         se vetor[i] mod 2 <> 0 entao
            escreval("Valor inválido! Digite um número par.")
         fimse

      ate vetor[i] mod 2 = 0

   fimpara

   escreval("")
   escreval("Valores na ordem inversa:")

   para i de 6 ate 1 passo -1 faca
      escreval(vetor[i])
   fimpara

fimalgoritmo
