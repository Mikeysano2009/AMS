programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 9"

var
   vetor: vetor[1..10] de real
   quadrados: vetor[1..10] de real
   i: inteiro

inicio

   para i de 1 ate 10 faca
      escreva("Digite o ", i, "º número: ")
      leia(vetor[i])

      quadrados[i] <- vetor[i] * vetor[i]
   fimpara

   escreval("")
   escreval("Vetor original:")

   para i de 1 ate 10 faca
      escreva(vetor[i]:0:2, " ")
   fimpara

   escreval("")
   escreval("")
   escreval("Vetor com os quadrados:")

   para i de 1 ate 10 faca
      escreva(quadrados[i]:0:2, " ")
   fimpara

   escreval("")

fimalgoritmo
