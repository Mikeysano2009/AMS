programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 1"

var
   valores: vetor[1..6] de inteiro
   i: inteiro

inicio

   para i de 1 ate 6 faca
      escreva("Digite o ", i, "º valor: ")
      leia(valores[i])
   fimpara

   escreval("")
   escreval("Valores lidos:")

   para i de 1 ate 6 faca
      escreval(valores[i])
   fimpara

fimalgoritmo
