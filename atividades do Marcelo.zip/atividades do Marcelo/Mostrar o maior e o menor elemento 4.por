programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 4"

var
   vetor: vetor[1..10] de inteiro
   i, maior, menor: inteiro

inicio

   para i de 1 ate 10 faca
      escreva("Digite o ", i, "º valor: ")
      leia(vetor[i])
   fimpara

   maior <- vetor[1]
   menor <- vetor[1]

   para i de 2 ate 10 faca

      se vetor[i] > maior entao
         maior <- vetor[i]
      fimse

      se vetor[i] < menor entao
         menor <- vetor[i]
      fimse

   fimpara

   escreval("")
   escreval("Maior elemento: ", maior)
   escreval("Menor elemento: ", menor)

fimalgoritmo
