programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 10"

var
   vetor: vetor[1..8] de inteiro
   X, Y, soma: inteiro
   i: inteiro

inicio

   para i de 1 ate 8 faca
      escreva("Digite o valor da posição ", i, ": ")
      leia(vetor[i])
   fimpara

   escreva("Digite a posição X: ")
   leia(X)

   escreva("Digite a posição Y: ")
   leia(Y)

   soma <- vetor[X] + vetor[Y]

   escreval("")
   escreval("Soma dos valores: ", soma)

fimalgoritmo
