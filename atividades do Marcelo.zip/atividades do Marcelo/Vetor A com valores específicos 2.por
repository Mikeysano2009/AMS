programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 2"

var
   A: vetor[0..5] de inteiro
   soma: inteiro
   i: inteiro

inicio

   A[0] =- 1
   A[1] =- 0
   A[2] =- 5
   A[3] =- -2
   A[4] =- -5
   A[5] =- 7

   soma <- A[0] + A[1] + A[5]

   escreval("Soma: ", soma)

   A[4] <- 100

   escreval("")
   escreval("Valores do vetor A:")

   para i de 0 ate 5 faca
      escreval(A[i])
   fimpara

fimalgoritmo

