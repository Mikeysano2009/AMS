programa {
  funcao inicio() {
    
  }
}
algoritmo "Exercicio 6"

var
   vetor: vetor[1..6] de inteiro
   i: inteiro

inicio

   para i de 1 ate 6 faca
      escreva("Digite o ", i, "º valor: ")
      leia(vetor[i])
   fimpara

   escreval("")
   escreval("Valores na ordem inversa:")

   para i de 6 ate 1 passo -1 faca
      escreval(vetor[i])
   fimpara

fimalgoritmo
